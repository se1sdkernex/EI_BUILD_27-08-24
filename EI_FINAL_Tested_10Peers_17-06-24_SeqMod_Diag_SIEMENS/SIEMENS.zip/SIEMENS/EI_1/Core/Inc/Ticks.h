/*
 * Ticks.h
 *
 *  Created on: May 11, 2023
 *      Author: Ravi Teja P
 */

#ifndef INC_TICKS_H_
#define INC_TICKS_H_

#include "Headers.h"

uint32_t HAL_Elaps_Ticks(uint32_t Ticks);

#endif /* INC_TICKS_H_ */
